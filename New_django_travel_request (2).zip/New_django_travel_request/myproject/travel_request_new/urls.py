from django.urls import path
from .views import (
    requests_list, view_request_by_id, add_request, get_assigned_manager,
    get_user_manager_details, update_request, resubmit_request,
    cancel_request, manager_assigned_requests, request_by_id,
    filter_requests, search_requests_by_id, update_travel_status,
    approve_request_with_note, admin_home_page, view_request_detail,
    clear_approved_requests, user_details, list_users, login_view,
    create_user_view, logout_view
)

urlpatterns = [
    path('requests/', requests_list, name='requests_list'),
    path('requests/<int:request_id>/', view_request_by_id, name='view_request_by_id'),
    path('requests/add/', add_request, name='add_request'),
    path('requests/update/<int:request_id>/', update_request, name='update_request'),
    path('requests/resubmit/<int:request_id>/', resubmit_request, name='resubmit_request'),
    path('requests/cancel/<int:request_id>/', cancel_request, name='cancel_request'),
    path('requests/manager/<int:manager_id>/', manager_assigned_requests, name='manager_assigned_requests'),
    path('requests/filter/', filter_requests, name='filter_requests'),
    path('requests/search/<int:request_id>/', search_requests_by_id, name='search_requests_by_id'),
    path('requests/status/<int:request_id>/', update_travel_status, name='update_travel_status'),
    path('requests/approve/<int:request_id>/', approve_request_with_note, name='approve_request_with_note'),

    path('admin/home/', admin_home_page, name='admin_home_page'),
    path('admin/request/<int:request_id>/', view_request_detail, name='view_request_detail'),
    path('admin/clear-approved/', clear_approved_requests, name='clear_approved_requests'),
    path('admin/user/<int:user_id>/', user_details, name='user_details'),
    path('admin/users/', list_users, name='list_users'),

    path('auth/login/', login_view, name='login_view'),
    path('auth/create-user/', create_user_view, name='create_user_view'),
    path('auth/logout/', logout_view, name='logout_view'),

    path('user/manager/', get_assigned_manager, name='get_assigned_manager'),
    path('user/details/', get_user_manager_details, name='get_user_manager_details'),
]

