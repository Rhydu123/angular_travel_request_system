from django.shortcuts import render,get_object_or_404
import requests
from django.utils.dateparse import parse_date
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny,IsAuthenticated  # Allows unauthenticated access for login
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from rest_framework import status
from django.core.mail import send_mail
from django.conf import settings 
from rest_framework.response import Response
from rest_framework.decorators import api_view,permission_classes
from rest_framework.status import HTTP_404_NOT_FOUND
from rest_framework.status import HTTP_204_NO_CONTENT
from rest_framework.status import HTTP_500_INTERNAL_SERVER_ERROR
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.status import HTTP_201_CREATED
from rest_framework.status import HTTP_200_OK
from rest_framework.status import HTTP_403_FORBIDDEN,HTTP_401_UNAUTHORIZED
from .models import Requests, Manager, Employee,UserProfile
from .serializers import RequestSerializer
from django.db.models import Q
from django.core.cache import cache

@permission_classes([IsAuthenticated])
@api_view(['GET'])
def requests_list(request):
    """Return a list of all requests."""
    requests = Requests.objects.all().select_related('employee', 'manager')  # Fetch related Employee & Manager    
    serializer = RequestSerializer(requests, many=True)  # Serialize the queryset
    return Response(serializer.data, status=HTTP_200_OK)

@permission_classes([IsAuthenticated])
@api_view(['GET'])
def view_request_by_id(request,request_id):
    """Retrieve a specific request by its ID."""
    try:
        request_obj = Requests.objects.get(id=request_id)
        serializer=RequestSerializer(request_obj)
        return Response(serializer.data,status=HTTP_200_OK)
    except Requests.DoesNotExist:
        return Response({
            "message":"Request not found"
        },status=HTTP_404_NOT_FOUND)
    
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_request(request):
    """Create a new request automatically assigned to a manager in the same department."""
    user = request.user  # Get the authenticated user

    # ✅ Ensure the user has a UserProfile
    try:
        user_profile = UserProfile.objects.get(user=user)
    except UserProfile.DoesNotExist:
        return Response(
            {"message": "User profile not found. Ensure you have a valid user profile."}, 
            status=status.HTTP_400_BAD_REQUEST
        )

    # ✅ Ensure user is an Employee
    if not user_profile.employee:
        return Response(
            {"message": "Only employees can submit travel requests."}, 
            status=status.HTTP_400_BAD_REQUEST
        )

    employee = user_profile.employee  # Get the employee object

    # ✅ Ensure employee has a department
    if not employee.department:
        return Response(
            {"message": "You must belong to a department to submit a request."}, 
            status=status.HTTP_400_BAD_REQUEST
        )

    # ✅ Find a manager in the same department
    manager = Manager.objects.filter(department=employee.department).first()
    if not manager:
        return Response(
            {"message": "No manager found for your department. Contact an administrator."}, 
            status=status.HTTP_400_BAD_REQUEST
        )

    # ✅ Prepare request data with employee and manager IDs
    request_data = request.data.copy()
    request_data["employee"] = employee.id  # ✅ Ensure employee ID is set
    request_data["manager"] = manager.id  # ✅ Ensure manager ID is set

    # ✅ Use partial=True to allow missing fields
    serializer = RequestSerializer(data=request_data, partial=True)

    if serializer.is_valid():
        serializer.save(employee=employee, manager=manager)  # ✅ Pass employee & manager explicitly
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
# get--assigned--manager
@permission_classes([AllowAny])
@api_view(['GET'])
def get_assigned_manager(request):
    """Retrieve the assigned manager for the logged-in employee before request submission."""
    try:
        employee = request.user.userprofile.employee
        manager = Manager.objects.filter(department=employee.department).first()

        if not manager:
            return Response({"message": "No manager found for your department"}, status=HTTP_400_BAD_REQUEST)

        return Response({
            "manager_id": manager.id,
            "manager_name": f"{manager.first_name} {manager.last_name}"
        }, status=HTTP_200_OK)

    except AttributeError:
        return Response({"message": "You are not registered as an employee or missing profile"}, status=HTTP_400_BAD_REQUEST)

@permission_classes([AllowAny])
@api_view(['GET'])
def get_user_manager_details(request):
    try:
        user = request.user
        user_profile = UserProfile.objects.filter(user=user).first()

        if not user_profile:
            return Response({"message": "User profile not found"}, status=HTTP_400_BAD_REQUEST)

        # Ensure the user is a manager
        if not user_profile.manager:
            return Response({"message": "User is not a manager"}, status=HTTP_400_BAD_REQUEST)

        manager = user_profile.manager
        return Response({
            "manager_id": manager.id,
            "manager_name": f"{manager.first_name} {manager.last_name}"
        }, status=HTTP_200_OK)

    except Exception as e:
        return Response({"message": f"Error: {str(e)}"}, status=HTTP_500_INTERNAL_SERVER_ERROR)


@permission_classes([IsAuthenticated])
@api_view(['PUT'])
def update_request(request, request_id):
    """Update an existing request by ID."""
    try:
        request_obj = Requests.objects.get(id=request_id)
    except Requests.DoesNotExist:
        return Response({"message": "Request not found"}, status=HTTP_404_NOT_FOUND)

    serializer = RequestSerializer(request_obj, data=request.data, partial=True)  # `partial=True` allows updating only specific fields
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=HTTP_200_OK)

    return Response(serializer.errors, status=HTTP_400_BAD_REQUEST)

@permission_classes([IsAuthenticated])
@api_view(['POST'])
def resubmit_request(request, request_id):
    """Resubmit an edited travel request for approval."""
    
    # Get the request object or return a 404 error
    travel_request = get_object_or_404(Requests, id=request_id)

    # Get the UserProfile to check if the logged-in user is an Employee
    try:
        user_profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        return Response({"message": "User profile not found"}, status=HTTP_400_BAD_REQUEST)

    # Ensure the user is an employee and owns the request
    if not user_profile.employee or user_profile.employee != travel_request.employee:
        return Response({"message": "You can only resubmit your own requests"}, status=HTTP_403_FORBIDDEN)

    # Ensure the request is in a resubmittable state (pending/rejected)
    if travel_request.is_pending is False and travel_request.is_rejected is False:
        return Response({"message": "Only pending or rejected requests can be resubmitted"}, status=HTTP_400_BAD_REQUEST)

    employee = user_profile.employee
    if not employee.department:
        return Response({"message": "You do not belong to any department"}, status=HTTP_400_BAD_REQUEST)

    # Assign the request to a manager in the same department
    manager = Manager.objects.filter(department=employee.department).first()
    if not manager:
        return Response({"message": "No manager found for your department"}, status=HTTP_400_BAD_REQUEST)

    # Update request status and manager
    travel_request.is_resubmitted = True
    travel_request.is_pending = True
    travel_request.is_rejected = False  # Reset rejection status
    travel_request.manager = manager  # Reassign manager
    travel_request.save()

    # Serialize and return updated data
    serializer = RequestSerializer(travel_request)
    return Response(serializer.data, status=HTTP_200_OK)

@permission_classes([IsAuthenticated])
@api_view(['DELETE'])
def cancel_request(request, request_id):
    """Cancel a request if it is not in progress."""
    request_obj = get_object_or_404(Requests, id=request_id)
    
    if request_obj.is_in_progress:
        return Response({"message": "Cannot cancel request that is in progress"}, status=HTTP_400_BAD_REQUEST)
    
    request_obj.delete()
    return Response({"message": "Request cancelled successfully"}, status=HTTP_204_NO_CONTENT)


#Manager
@permission_classes([IsAuthenticated])
@api_view(['GET'])
def manager_assigned_requests(request, manager_id):
    """Retrieve all requests assigned to a specific manager."""
    requests = Requests.objects.filter(manager_id=manager_id)
    serializer = RequestSerializer(requests, many=True)
    return Response(serializer.data, status=HTTP_200_OK)

@permission_classes([IsAuthenticated])
@api_view(['GET'])
def request_by_id(request, request_id):
    """Get a request by its ID."""
    request_obj = get_object_or_404(Requests, id=request_id)
    serializer = RequestSerializer(request_obj)
    return Response(serializer.data, status=HTTP_200_OK)

# .....Filtering..........
@permission_classes([IsAuthenticated])
@api_view(['GET'])
def filter_requests(request):
    """Filter requests by date range, employee name, and sort by employee first name."""
    requests = Requests.objects.all()

    # âœ… Get the query parameters correctly
    start_date = request.GET.get('start_date', None)
    end_date = request.GET.get('end_date', None)
    name = request.GET.get('name', None)

    # âœ… Filter by date range if both dates are provided
    if start_date and end_date:
        start_date = parse_date(start_date)
        end_date = parse_date(end_date)

        if not start_date or not end_date:
            return Response({"error": "Invalid date format. Use YYYY-MM-DD."}, status=400)

        requests = requests.filter(starting_date__range=[start_date, end_date])

    # âœ… Filter by employee's first name or last name
    if name:
        requests = requests.filter(
            Q(employee__first_name__icontains=name) | Q(employee__last_name__icontains=name)
        )

    # âœ… Sort results by employee's first name
    requests = requests.order_by('employee__first_name')

    # âœ… Ensure you return a valid response
    serializer = RequestSerializer(requests, many=True)
    return Response(serializer.data, status=HTTP_200_OK)


@permission_classes([IsAuthenticated])
@api_view(['GET'])
def search_requests_by_id(request, request_id):
    """Search for requests matching a specific ID."""
    try:
        requests = Requests.objects.filter(id=request_id)  # Filter instead of get()
        serializer = RequestSerializer(requests, many=True)  # Return as a list
        return Response(serializer.data, status=HTTP_200_OK)
    except Exception as e:
        return Response({"error": str(e)}, status=HTTP_400_BAD_REQUEST)

@permission_classes([IsAuthenticated])
@api_view(['PUT'])
def update_travel_status(request, request_id):
    """Update the status of a travel request to approved, rejected, in_progress, or pending."""
    request_obj = get_object_or_404(Requests, id=request_id)
    status = request.data.get("status")
    if status not in ["approved", "rejected", "in_progress", "pending"]:
        return Response({"message": "Invalid status"}, status=HTTP_400_BAD_REQUEST)
    
    request_obj.is_approved = status == "approved"
    request_obj.is_rejected = status == "rejected"
    request_obj.is_in_progress = status == "in_progress"
    request_obj.is_pending = status == "pending"
    request_obj.save()
    
    return Response({"message": f"Request status updated to {status}"}, status=HTTP_200_OK)

@permission_classes([IsAuthenticated])
@api_view(['PUT'])
def approve_request_with_note(request, request_id):
    """Approve a request with an accompanying note."""
    request_obj = get_object_or_404(Requests, id=request_id)
    note = request.data.get("note")
    if not note:
        return Response({"message": "Approval note is required"}, status=HTTP_400_BAD_REQUEST)
    
    request_obj.is_approved = True
    request_obj.is_pending = False
    request_obj.is_in_progress = False
    request_obj.is_rejected = False
    request_obj.approval_note = note
    request_obj.save()
    
    return Response({"message": "Request approved with note"}, status=HTTP_200_OK)

#Admin
@permission_classes([IsAuthenticated])
@api_view(['GET'])
def admin_home_page(request):
    """Provide all requests for the admin dashboard."""
    requests = Requests.objects.all()
    serializer = RequestSerializer(requests, many=True)
    return Response(serializer.data, status=HTTP_200_OK)

@permission_classes([IsAuthenticated])
@api_view(['GET'])
def view_request_detail(request, request_id):
    """Display detailed information for a specific request."""
    request_obj = get_object_or_404(Requests, id=request_id)
    serializer = RequestSerializer(request_obj)
    return Response(serializer.data, status=HTTP_200_OK)

@permission_classes([IsAuthenticated])
@api_view(['DELETE'])
def clear_approved_requests(request):
    """Remove all requests that have been approved."""
    approved_requests = Requests.objects.filter(travelstatus__is_approved=True)
    count = approved_requests.count()
    approved_requests.delete()
    return Response({"message": f"Cleared {count} approved requests"}, status=HTTP_204_NO_CONTENT)


@permission_classes([IsAuthenticated])
@api_view(['GET'])
def user_details(request, user_id):
    """Retrieve details for a specific user based on their role."""
    user = get_object_or_404(UserProfile, id=user_id)
    if user.role == "manager":
        user_details = get_object_or_404(Manager, id=user.manager_id)
    elif user.role == "employee":
        user_details = get_object_or_404(Employee, id=user.employee_id)
    else:
        return Response({"message": "Invalid user role"}, status=HTTP_400_BAD_REQUEST)
    
    return Response({
        # "username": user.user_name,
        "phone_no": user.phone_no,
        "role": user.role,
        "first_name": user_details.first_name,
        "last_name": user_details.last_name,
        "email_id": user_details.email_id,
    }, status=HTTP_200_OK)

# Backend view to fetch all users
@permission_classes([IsAuthenticated])
@api_view(['GET'])
def list_users(request):
    """Retrieve a list of all users (employees and managers)."""
    users = UserProfile.objects.all().values('id', 'user__username','user__email', 'role', 'employee_id', 'manager_id')
    return Response(users, status=HTTP_200_OK)


@api_view(['POST'])
@permission_classes([AllowAny])
def login_view(request):
    """Authenticate user and provide access token."""
    username = request.data.get("username")
    password = request.data.get("password")

    if not username or not password:
        return Response(
            {"message": "Both username and password are required."},
            status=status.HTTP_400_BAD_REQUEST
        )

    # Authenticate user
    user = authenticate(username=username, password=password)

    if user is None:
        return Response(
            {"message": "Invalid credentials."},
            status=status.HTTP_400_BAD_REQUEST
        )

    # Get or create token
    token, _ = Token.objects.get_or_create(user=user)

    # ✅ Assign userId before using it
    userId = user.id

    # ✅ Default role assignment
    role = "employee"

    # ✅ Try to determine role from UserProfile
    try:
        profile = user.userprofile
        role = profile.role
    except UserProfile.DoesNotExist:
        # ✅ Fallback to built-in Django flags
        if user.is_superuser:
            role = "admin"
        elif user.is_staff:
            role = "manager"

    return Response(
        {"token": token.key, "role": role, "userId": userId},
        status=status.HTTP_200_OK
    )

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_user_view(request):
    """Create a new user with role-specific properties."""
    if not request.user.is_superuser:
        return Response({"message": "Only an admin can create new users."},
                        status=status.HTTP_403_FORBIDDEN)

    data = request.data
    username = data.get("username")
    password = data.get("password")
    email = data.get("email")
    first_name = data.get("first_name", "")
    last_name = data.get("last_name", "")
    role = data.get("role", "").lower()
    department = data.get("department", "")

    if not username or not password or not email or not department:
        return Response(
            {"message": "Username, password, email, and department are required."},
            status=status.HTTP_400_BAD_REQUEST
        )

    if role not in ["employee", "manager", "admin"]:
        return Response(
            {"message": "Role must be 'employee', 'manager', or 'admin'."},
            status=status.HTTP_400_BAD_REQUEST
        )

    user_auth = User.objects.create_user(username=username, password=password, email=email, first_name=first_name, last_name=last_name)

    if role == "admin":
        user_auth.is_superuser = True
        user_auth.is_staff = True
        user_auth.save()
        return Response({"message": f"Admin user '{username}' created successfully."}, status=status.HTTP_201_CREATED)

    # Creating UserProfile
    user_profile = UserProfile.objects.create(user=user_auth, role=role)

    if role == "manager":
        manager = Manager.objects.create(
            first_name=first_name,
            last_name=last_name,
            department=department,
            email_id=email
        )
        user_profile.manager = manager
        user_auth.is_staff = True  # Managers are staff members
    elif role == "employee":
        manager = Manager.objects.filter(department=department).first()  # Assign first manager in the department
        employee = Employee.objects.create(
            first_name=first_name,
            last_name=last_name,
            department=department,
            email_id=email,
            manager=manager  # Assign a manager if available
        )
        user_profile.employee = employee

    user_profile.save()
    user_auth.save()

    return Response({"message": f"User '{username}' created successfully as {role}."}, status=status.HTTP_201_CREATED)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def logout_view(request):
    """Log out a user by deleting their authentication token."""
    try:
        # Delete the user's token to log them out.
        token = Token.objects.get(user=request.user)
        token.delete()
        return Response({"message": "Successfully logged out."}, status=status.HTTP_200_OK)
    except Token.DoesNotExist:
        return Response({"message": "Token not found."}, status=status.HTTP_400_BAD_REQUEST)