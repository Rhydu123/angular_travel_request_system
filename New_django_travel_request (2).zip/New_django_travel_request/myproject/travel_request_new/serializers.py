from rest_framework import serializers
from .models import Manager, Employee, UserProfile, Requests, Admin
from django.contrib.auth.models import User
from datetime import date


class ManagerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Manager
        fields = '__all__'

class EmployeeSerializer(serializers.ModelSerializer):
    manager = ManagerSerializer(read_only=True)

    class Meta:
        model = Employee
        fields = '__all__'

class UserProfileSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField()
    employee = EmployeeSerializer(read_only=True)
    manager = ManagerSerializer(read_only=True)

    class Meta:
        model = UserProfile
        fields = '__all__'

class RequestSerializer(serializers.ModelSerializer):
    employee = EmployeeSerializer(read_only=True)
    manager = ManagerSerializer(read_only=True)
    starting_date = serializers.DateField(required=True)
    ending_date = serializers.DateField(required=True)

    class Meta:
        model = Requests
        fields = '__all__'

class AdminSerializer(serializers.ModelSerializer):
    class Meta:
        model = Admin
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']
