from django.db import models
from django.contrib.auth.models import User
from datetime import date

class Manager(models.Model):
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    department = models.CharField(max_length=150)
    date_of_joining = models.DateField(default=date.today)
    email_id = models.EmailField(unique=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.department})"

class Employee(models.Model):
    first_name = models.CharField(max_length=250)
    last_name = models.CharField(max_length=250)
    date_of_joining = models.DateField(default=date.today)
    department = models.CharField(max_length=150)
    gender = models.CharField(max_length=100)
    email_id = models.EmailField(unique=True)
    manager = models.ForeignKey(Manager, on_delete=models.SET_NULL, null=True, blank=True)  # Employee reports to a Manager

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.department})"

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_no = models.CharField(max_length=15, blank=True, null=True)
    role = models.CharField(max_length=100, choices=[
        ('Admin', 'Admin'),
        ('Manager', 'Manager'),
        ('Employee', 'Employee')
    ])
    # Link to Employee or Manager profile if applicable
    employee = models.OneToOneField(Employee, on_delete=models.SET_NULL, null=True, blank=True)
    manager = models.OneToOneField(Manager, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.user.username

class Requests(models.Model):
    from_location = models.CharField(max_length=200)
    to_location = models.CharField(max_length=200)
    travel_mode = models.CharField(max_length=100)
    starting_date = models.DateField()
    ending_date = models.DateField()
    is_lodging_required = models.BooleanField(default=False)
    lodging_location = models.CharField(max_length=250, blank=True, null=True)
    travel_purpose = models.TextField()
    additional_requests = models.TextField(blank=True, null=True)

    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)  # Request made by an Employee
    manager = models.ForeignKey(Manager, on_delete=models.SET_NULL, null=True, blank=True)  # Manager for approval

    is_resubmitted = models.BooleanField(default=False)
    is_additional_info_required = models.BooleanField(default=False)

    # Travel Request Status
    is_approved = models.BooleanField(default=False)
    is_rejected = models.BooleanField(default=False)
    is_in_progress = models.BooleanField(default=False)
    is_pending = models.BooleanField(default=True)

    approval_note = models.TextField(blank=True, null=True)
    rejection_note = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Request from {self.employee} to {self.to_location} - {'Approved' if self.is_approved else 'Pending'}"

class Admin(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    email_id = models.EmailField(unique=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

