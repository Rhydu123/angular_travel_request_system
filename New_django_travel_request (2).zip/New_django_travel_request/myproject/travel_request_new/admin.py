from django.contrib import admin
from .models import Manager, Employee, UserProfile, Requests, Admin

admin.site.register(Manager)
admin.site.register(Employee)
admin.site.register(UserProfile)
admin.site.register(Requests)
admin.site.register(Admin)
